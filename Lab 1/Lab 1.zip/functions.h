#include <stdio.h>
#include <stdlib.h>

void checkFile(FILE*);

void checkArguments(int num);

void checkBraces(FILE* fp);