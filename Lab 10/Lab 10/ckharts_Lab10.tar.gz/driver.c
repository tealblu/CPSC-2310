/* Charlie Hartsell
    CPSC 2311 Lab 10
    Sec 002
    April 14, 2020 */

#include <stdio.h>

int main(void) {
    int min = 0;
    int max = 10;

    for(int i = min; i <= max; min++) {
        printf("%d", i);
    }

    printf("\n");
    return 0;
}