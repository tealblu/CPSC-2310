/** CPSC 2310 Lab 4

    Nibble routines

    Nibbles are 4-bit parts of a 32 bit unsigned integer variable.  
    Nibbles are numbered 0-7 from left to right.

**/
#include "functions.h"


unsigned int nget(unsigned int val, int position) {
   /** STUBBED **/
   return(0);
}

unsigned int nset(unsigned int val, unsigned int nVal, int position) {
   /** STUBBED **/
   return(0);
}

unsigned int nlrotate(unsigned int val) {
   /** STUBBED **/
   return(0);
}
