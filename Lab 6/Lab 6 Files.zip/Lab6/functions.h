int printReturn( int a, int b, int action);
