#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <stdio.h>

int isArithmetic();
int isOddOne(unsigned);

#endif