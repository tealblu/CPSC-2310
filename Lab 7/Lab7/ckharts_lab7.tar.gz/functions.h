/** Charlie Hartsell
 * CPSC 2310 Lab 7
 * Username: ckharts
 * Section 002 */

#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <stdio.h>

int isArithmetic();
int isOddOne(unsigned);

#endif