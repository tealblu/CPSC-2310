
int readSize(FILE*);
void readData(FILE* fp, int, int*, int*);
int* allocateMemory(int);
int* compareElements(int sz, int* arr1, int* arr2);

