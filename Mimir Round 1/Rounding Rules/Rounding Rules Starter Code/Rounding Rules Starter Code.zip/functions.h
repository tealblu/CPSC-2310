int* readData(FILE*, int*);
void determineGrade(int* , int);
void printGrade(int, int* );
void checkArguments(int);
void checkFile(FILE*);
void calculatePercent(int, int*);
void printGraph(int);
